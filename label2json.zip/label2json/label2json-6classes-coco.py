# 导入包
import os
import io
import json
import numpy as np
from PIL import Image
import base64
import cv2
# 定义路径
ROOT_DIR = r'D:\UESD'  # 请修改为你的文件根目录
Image_DIR = os.path.join(ROOT_DIR, "images")  # 包含图片的目录
Label_DIR = os.path.join(ROOT_DIR, "labels")  # 包含label文件的目录
JSON_DIR = os.path.join(ROOT_DIR, "json")  # 保存生成的COCO格式JSON文件的目录

if not os.path.exists(JSON_DIR):
    os.makedirs(JSON_DIR)

Label_files = os.listdir(Label_DIR)

# 注意：这里的 class_names 中的索引对应于像素标签值，0为背景，1~5为具体目标类别
class_names = {
    1: 'class1',
    2: 'class2',
    3: 'class3',
    4: 'class4',
    5: 'class5'
}

# 创建COCO格式JSON的基本结构
coco_output = {
    "info": {
        "description": "Dataset in COCO format",
        "version": "1.0",
        "year": 2024,
        "contributor": "YourName",
        "date_created": "2024-12-04"
    },
    "licenses": [
        {
            "id": 1,
            "name": "Unknown",
            "url": "http://example.com"
        }
    ],
    "images": [],
    "annotations": [],
    "categories": []
}

# 填充类别信息
for category_id, category_name in class_names.items():
    coco_output["categories"].append({
        "id": category_id,
        "name": category_name,
        "supercategory": "none"
    })

annotation_id = 1  # 注释ID起始值
image_id = 1       # 图像ID起始值

for Label_filename in Label_files:
    print("处理文件:", Label_filename)
    name = Label_filename.split('.')[0]
    name1 = name + '.png'  # 确保图片文件后缀为 PNG

    # 打开图像
    image = Image.open(os.path.join(Image_DIR, name1))
    width, height = image.size

    # 添加图像信息到 COCO 的 `images` 字段
    coco_output["images"].append({
        "id": image_id,
        "file_name": name1,
        "width": width,
        "height": height,
    })

    # 打开标签文件并处理
    binary_mask = np.array(Image.open(os.path.join(Label_DIR, Label_filename))).astype(np.uint8)

    for category_id in np.unique(binary_mask):
        if category_id == 0:  # 跳过背景
            continue

        # 创建二值掩码
        temp_mask = np.where(binary_mask == category_id, 1, 0).astype(np.uint8)

        # 查找连通区域并生成多边形
        contours, _ = cv2.findContours(temp_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            if len(contour) < 6:  # 忽略太小的多边形
                continue

            segmentation = contour.flatten().tolist()  # 转为COCO需要的点列表格式
            x, y, w, h = cv2.boundingRect(contour)  # 获取边界框
            area = cv2.contourArea(contour)  # 计算区域面积

            # 添加注释到 COCO 的 `annotations` 字段
            annotation = {
                "id": annotation_id,
                "image_id": image_id,
                "category_id": int(category_id),
                "segmentation": [segmentation],
                "area": float(area),
                "bbox": [x, y, w, h],
                "iscrowd": 0
            }
            coco_output["annotations"].append(annotation)
            annotation_id += 1

    image_id += 1

# 保存为 COCO 格式的 JSON 文件
output_path = os.path.join(JSON_DIR, 'dataset_coco_format.json')
with open(output_path, 'w', encoding='utf-8') as output_json_file:
    json.dump(coco_output, output_json_file, ensure_ascii=False, indent=4)

print("COCO格式JSON文件已保存至:", output_path)