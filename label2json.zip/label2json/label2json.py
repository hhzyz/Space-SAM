# 导入包
import os
import io
import json
import numpy as np
from PIL import Image
import base64
from pycococreatortools.tool import binary_mask_to_polygon


def img_tobyte(img_pil):
    """
    该函数用于将图像转化为base64字符类型
    :param img_pil: Image类型
    :return base64_string: 字符串
    """
    ENCODING = 'utf-8'
    img_byte = io.BytesIO()
    img_pil.save(img_byte, format='PNG')
    binary_str2 = img_byte.getvalue()
    imageData = base64.b64encode(binary_str2)
    base64_string = imageData.decode(ENCODING)
    return base64_string


# 定义路径
ROOT_DIR = r'E:\DataSets\renxingdao_dataset'  # 请输入你文件的根目录
Image_DIR = os.path.join(ROOT_DIR, "images")  # 目录底下包含图片
Label_DIR = os.path.join(ROOT_DIR, "labels")  # 目录底下包含label文件
JSON_DIR = os.path.join(ROOT_DIR, "json")  # 用于保存json文件的目录

if not os.path.exists(JSON_DIR):
    os.makedirs(JSON_DIR)

Label_files = os.listdir(Label_DIR)
class_names = ['0', '1']  # todo 分别表示label标注图中1对应背景，2对应目标1。
for Label_filename in Label_files:
    # 创建一个json文件
    Json_output = {
        "version": "3.16.7",
        "flags": {},
        "fillColor": [255, 0, 0, 128],
        "lineColor": [0, 255, 0, 128],
        "imagePath": {},
        "shapes": [],
        "imageData": {}}
    print(Label_filename)
    name = Label_filename.split('.')[0]
    name1 = name + '.jpg'  # todo
    Json_output["imagePath"] = name1
    # 打开原图并将其转化为labelme json格式
    image = Image.open(os.path.join(Image_DIR, name1))
    imageData = img_tobyte(image)
    Json_output["imageData"] = imageData
    binary_mask = np.asarray(np.array(Image.open(os.path.join(Label_DIR, Label_filename)))).astype(np.uint8)
    # 分别对掩码中的label结果绘制边界点
    for i in np.unique(binary_mask):
        # print('i:', i)
        if i != 0:
            temp_mask = np.where(binary_mask == i, 1, 0)
            segmentation = binary_mask_to_polygon(temp_mask, tolerance=2)  # tolerancec参数控制无误差
            for item in segmentation:
                if len(item) > 10:
                    list1 = []
                    for j in range(0, len(item), 2):
                        list1.append([item[j], item[j + 1]])
                    # print(i)
                    label = class_names[i]  #
                    seg_info = {'points': list1, "fill_color": None, "line_color": None, "label": label,
                                "shape_type": "polygon", "flags": {}}
                    Json_output["shapes"].append(seg_info)
    Json_output["imageHeight"] = binary_mask.shape[0]
    Json_output["imageWidth"] = binary_mask.shape[1]
    # 保存在根目录下的json文件中
    full_path = os.path.join(JSON_DIR, name + '.json')
    with open(full_path, 'w') as output_json_file:
        json.dump(Json_output, output_json_file)
