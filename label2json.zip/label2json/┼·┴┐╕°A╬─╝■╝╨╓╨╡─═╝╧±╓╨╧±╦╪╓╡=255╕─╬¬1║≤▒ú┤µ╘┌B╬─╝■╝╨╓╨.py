from PIL import Image
import os


def process_image(image_path, target_folder):
    """
    处理单个图像：转换为8位，并将像素值为2的改为0
    :param image_path: 图像的文件路径
    :param target_folder: 保存处理后图像的目标文件夹
    """
    with Image.open(image_path) as img:
        # 转换为8位图像（通常是灰度图像）
        img = img.convert("L")

        # 修改像素值
        pixels = img.load()
        for i in range(img.size[0]):  # 遍历宽度
            for j in range(img.size[1]):  # 遍历高度
                if pixels[i, j] == 255:
                    pixels[i, j] = 1

        # 保存处理后的图像
        img.save(os.path.join(target_folder, os.path.basename(image_path)))


def batch_process_images(source_folder, target_folder):
    """
    批量处理文件夹中的图像
    :param source_folder: 源文件夹路径
    :param target_folder: 目标文件夹路径
    """
    if not os.path.exists(target_folder):
        os.makedirs(target_folder)

    for filename in os.listdir(source_folder):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
            process_image(os.path.join(source_folder, filename), target_folder)


# 示例使用
source_folder = r'D:\DeepLearning\Project\data_mask2json\GT0255'  # 替换为你的源文件夹路径
target_folder = r'D:\DeepLearning\Project\data_mask2json\GT'  # 替换为你的目标文件夹路径
batch_process_images(source_folder, target_folder)
