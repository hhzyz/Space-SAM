import numpy as np
import cv2


def add_gaussian_noise(image):
    mean = 0
    sigma = 25
    img_height,img_width,img_channels = image.shape

    gauss = np.random.normal(mean,sigma,(img_height,img_width,img_channels))
    noisy_img = image + gauss
    noisy_img = np.clip(noisy_img,a_min=0,a_max=255)

    return noisy_img


def add_salt_noise(image):
    s_vs_p = 0.5
    amount = 0.04
    noisy_img = np.copy(image)
    num_salt = np.ceil(amount * image.size * s_vs_p)

    coords = [np.random.randint(0,i - 1, int(num_salt)) for i in image.shape]
    noisy_img[coords[0],coords[1],:] = [255,255,255]

    num_pepper = np.ceil(amount * image.size * (1. - s_vs_p))

    coords = [np.random.randint(0,i - 1, int(num_pepper)) for i in image.shape]
    noisy_img[coords[0],coords[1],:] = [0,0,0]

    return noisy_img


def add_poisson_noise(image):
    vals = len(np.unique(image))
    vals = 2 ** np.ceil(np.log2(vals))

    noisy_img = np.random.poisson(image * vals) / float(vals)

    return noisy_img

def get_filename(path):
    import os
    k=os.listdir(path)
    return k

def generate_image_path(PATH,image_name):
    data = str(PATH + '/' + image_name)
    return data


if __name__ == "__main__":
    # open folder
    # view all images in this folder 
    # for ..
    #   view each image 
    #   save noise images
    # end for
    PATH = 'D:\\ZYZ\\biyedaima\\efficientvit-master\\.demo'
    image_file_names = get_filename(PATH)
    total_num = len(image_file_names)
    print('total images num is %d',total_num)
    SAVE_PATH='D:\\biyedaima\\ceshi'
    for i in range(total_num):
        image_path=generate_image_path(PATH,image_file_names[i])
        img = cv2.imread(image_path)
        # noise_img = add_gaussian_noise(img)
        # noise_img = add_salt_noise(img)
        noise_img = add_poisson_noise(img)
        save_image_path=generate_image_path(SAVE_PATH,image_file_names[i])
        img_save = cv2.imwrite(save_image_path,noise_img)




